{{- define "common.cloudflare-ingress" -}}
{{- if .Values.cloudflare.enabled }}
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ include "common.fullname" . }}
  namespace: {{ .Values.namespace }}
  labels:
    {{- include "common.labels" . | nindent 4 }}
spec:
  ingressClassName: cloudflare-tunnel
  rules:
    - host: {{ .Values.cloudflare.hostname }}
      http:
        paths:
          - path: {{ .Values.cloudflare.path }}
            pathType: {{ .Values.cloudflare.pathType }}
            backend:
              service:
                name: {{ include "common.fullname" . }}
                port:
                  number: {{ .Values.service.port }}
{{- end }}
{{- end }}
